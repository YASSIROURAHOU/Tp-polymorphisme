public class main {
    public static void main(String[] args) {
        // Créer un tableau de références Véhicule
        Vehicule[] vehicules = {
                new Voiture(),
                new Velo(),
                new Bateau()
        };

        double distance = 150; // Distance en kilomètres

        // Calculer et afficher le temps de trajet pour chaque véhicule
        for (Vehicule vehicule : vehicules) {
            double tempsTrajet = vehicule.calculerTempsTrajet(distance);
            System.out.println("Pour une distance de " + distance + " km :");
            if (vehicule instanceof Voiture) {
                System.out.println("Une Voiture devrait mettre " + String.format("%.2f", tempsTrajet) + " heures.");
            } else if (vehicule instanceof Velo) {
                System.out.println("Un Vélo devrait mettre " + String.format("%.2f", tempsTrajet) + " heures.");
            } else if (vehicule instanceof Bateau) {
                System.out.println("Un Bateau devrait mettre " + String.format("%.2f", tempsTrajet) + " heures.");
            }
        }
    }
}