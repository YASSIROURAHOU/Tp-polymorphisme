class Voiture extends Vehicule {
    public Voiture() {
        this.vitesseMoyenne = 100; // Vitesse moyenne en km/h
    }

    @Override
    public double calculerTempsTrajet(double distance) {
        return distance / vitesseMoyenne;
    }
}