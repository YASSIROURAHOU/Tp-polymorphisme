abstract class Vehicule {
    protected double vitesseMoyenne; // Vitesse moyenne en km/h

    // Méthode abstraite pour calculer le temps de trajet
    public abstract double calculerTempsTrajet(double distance);
}