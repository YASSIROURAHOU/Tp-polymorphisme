class Bateau extends Vehicule {
    public Bateau() {
        this.vitesseMoyenne = 40; // Vitesse moyenne en km/h
    }

    @Override
    public double calculerTempsTrajet(double distance) {
        return distance / vitesseMoyenne;
    }
}