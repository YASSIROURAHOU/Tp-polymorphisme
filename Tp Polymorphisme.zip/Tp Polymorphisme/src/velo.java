class Velo extends Vehicule {
    public Velo() {
        this.vitesseMoyenne = 15; // Vitesse moyenne en km/h
    }

    @Override
    public double calculerTempsTrajet(double distance) {
        return distance / vitesseMoyenne;
    }
}